package com.test.rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;

@Path("/xml")
public class XmlTest {

	// @GET
	// @Produces(MediaType.TEXT_XML)
	// public String getXml() {
	// return "<a>" + "Thisisaneasyresource(ashtmltext)." + "</a>";
	// }

	@GET
	@Produces( { MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Test listPageByPropertiesWithSort() {
		Test map = new Test("1", "111");
		return map;
	}

	// 请求 纯文本
	@GET
	@Produces(MediaType.TEXT_XML)
	public Test getUser() throws Exception {
		Test user = new Test("2", "2");
		for (String header : headers.getRequestHeaders().keySet()) {
			System.out.println("This header was set: " + header);
			System.out.println("    " + header + ": " + headers.getRequestHeader(header));
		}
		return user;
	}

	@Context
	private HttpHeaders headers;


	public static void main(String[] args) {
		Client c = Client.create();
		WebResource wr = c.resource("http://localhost:8080/Rest/rs/xml");
		String txtRes = wr.accept(MediaType.TEXT_XML).get(String.class);
		System.out.println("" + txtRes);

		txtRes = wr.accept(MediaType.APPLICATION_XML).get(String.class);
		System.out.println("" + txtRes);

		txtRes = wr.accept(MediaType.APPLICATION_JSON).get(String.class);
		System.out.println("" + txtRes);

	}
}