package com.test.rest;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.UriInfo;

import com.google.gson.Gson;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;

@Path("/json")
public class JsonTest {
	@Context
	UriInfo uriInfo;
	@Context
	Request request;

	@GET
	@Produces( { MediaType.APPLICATION_XML })
	@Consumes( { MediaType.APPLICATION_XML })
	public Test xml() {
		Test map = new Test("1", "111");
		return map;
	}

	@GET
	@Produces( { MediaType.APPLICATION_JSON })
	@Consumes( { MediaType.APPLICATION_JSON })
	public Test json() {
		Test map = new Test("1", "111");
		return map;
	}

	@GET
	@Produces( { MediaType.TEXT_PLAIN })
	@Consumes( { MediaType.TEXT_PLAIN })
	public String txt() {
		Test test = new Test("1", "111");
		String json = new Gson().toJson(test, Test.class);
		return json;
	}

	public static void main(String[] args) {
		Client c = Client.create();
		WebResource r = c.resource("http://localhost:8080/Rest/rs/json");
		String jsonRes = r.accept(MediaType.APPLICATION_XML).get(String.class);
		System.out.println(jsonRes);
		jsonRes = r.accept(MediaType.APPLICATION_JSON).get(String.class);
		System.out.println(jsonRes);
		jsonRes = r.accept(MediaType.TEXT_PLAIN).get(String.class);
		System.out.println(jsonRes);
	}
}