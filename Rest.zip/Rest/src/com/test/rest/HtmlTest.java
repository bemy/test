package com.test.rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/html")
public class HtmlTest {

	@GET
	@Produces(MediaType.TEXT_HTML)
	public String getHtml() {
		return "\n<font color='red'>" + "Thisisaneasyresource(ashtmltext).\n"
				+ "</font>";
	}
}