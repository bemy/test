package com.test.rest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class JsonTester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<List<Map<String, String>>> obj = new ArrayList<List<Map<String, String>>>();
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		Map<String, String> map = new HashMap<String, String>();
		map.put("1", "1");
		map.put("2", "2");
		map.put("3", "3");
		list.add(map);
		obj.add(list);
		Gson gson = new Gson();
		String json = gson.toJson(obj,
				new TypeToken<List<List<Map<String, String>>>>() {
				}.getType());// to Json
		System.out.println(json);
		List<List<Map<String, String>>> obj2 = gson.fromJson(json,
				new TypeToken<List<List<Map<String, String>>>>() {
				}.getType());// from json
		System.out.println(obj2);

		Test test = new Test("1", "234");
		String beanJson = gson.toJson(test, Test.class);
		System.out.println(beanJson);
		Test test2 = gson.fromJson(beanJson, Test.class);
		System.out.println(test2);
	}
}
